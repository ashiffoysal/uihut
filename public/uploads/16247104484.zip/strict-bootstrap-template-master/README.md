# strict-bootstrap-template
This html and css website template name strict. This is conversion from PSD to Bootstrap Template. Enjoy! Feel free to use this file

Author name: Faiz@meko
Author URI: mekoarts.blogspot.my
